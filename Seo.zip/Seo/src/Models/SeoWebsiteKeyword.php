<?php

namespace Modules\Seo\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SeoWebsiteKeyword extends Model
{
    use HasFactory;


    protected $primaryKey = 'id';

    protected $guarded = [
        'id'
    ];

    public $timestamps = false;



    public function getTable()
    {
        return config('dbtable.seo_website_keyword');
    }


    public function ranking_info()
    {
        return $this->hasMany(SeoWebsiteRanking::class,  'keyword_id', 'id');
    }
}
