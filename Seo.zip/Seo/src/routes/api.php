<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\Seo\Http\Controllers\SeoWebRedirectorController;
use Modules\Seo\Http\Controllers\SeoSettingController;
use Modules\Seo\Http\Controllers\SeoSubmissionController;
use Modules\Seo\Http\Controllers\SeoWorkController;
use Modules\Seo\Http\Controllers\SeoReportController;
use Modules\Seo\Http\Controllers\SeoResultController;







/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['ApiTokenCheck'], 'prefix' => "api/"], function () {



    Route::group(['prefix' => 'seoSetting'], function () {
        Route::post('/', [SeoSettingController::class, 'index']);
        Route::post('/website_store', [SeoSettingController::class, 'websetting_store']);
        Route::post('/website_edit', [SeoSettingController::class, 'websetting_edit']);
        Route::post('/website_update', [SeoSettingController::class, 'websetting_update']);
        Route::post('/website_destroy', [SeoSettingController::class, 'websetting_destroy']);
        Route::post('/changeWebsiteStatus', [SeoSettingController::class, 'changeWebsiteStatus']);
        Route::post('/changeTaskDuplicate', [SeoSettingController::class, 'changeTaskDuplicate']);


        Route::post('/website_create', [SeoSettingController::class, 'websetting_create']);
        Route::post('/task_manage', [SeoSettingController::class, 'task_manage']);
        Route::post('/manage_task_update', [SeoSettingController::class, 'manage_task_update']);
        Route::post('/changeTaskManageStatus', [SeoSettingController::class, 'changeTaskManageStatus']);
        Route::post('/keyword_manage', [SeoSettingController::class, 'keyword_manage']);
        Route::post('/keyword_update', [SeoSettingController::class, 'keyword_update']);
        Route::post('/web_ranking', [SeoSettingController::class, 'web_ranking']);
        Route::post('/web_ranking_update', [SeoSettingController::class, 'web_ranking_update']);



        Route::post('/task_submission', [SeoSettingController::class, 'task_submission']);
        Route::post('/task_priority', [SeoSettingController::class, 'task_priority']);


        //seo task api
        Route::post('/seo_task_store', [SeoSettingController::class, 'seo_task_store']);
        Route::post('/seo_task_edit', [SeoSettingController::class, 'seo_task_edit']);
        Route::post('/seo_task_update', [SeoSettingController::class, 'seo_task_update']);
        Route::post('/seo_task_destroy', [SeoSettingController::class, 'seo_task_destroy']);
        Route::post('/changeTaskStatus', [SeoSettingController::class, 'changeTaskStatus']);
        Route::post('/seo_task_create', [SeoSettingController::class, 'seo_task_create']);
        //end seo task 

        //seo result api
        Route::post('/seo_result_store', [SeoSettingController::class, 'seo_result_store']);
        Route::post('/seo_result_edit', [SeoSettingController::class, 'seo_result_edit']);
        Route::post('/seo_result_update', [SeoSettingController::class, 'seo_result_update']);
        Route::post('/seo_result_destroy', [SeoSettingController::class, 'seo_result_destroy']);
        Route::post('/changeResultStatus', [SeoSettingController::class, 'changeResultStatus']);
        Route::post('/seo_result_create', [SeoSettingController::class, 'seo_result_create']);
        Route::post('/result_sortOrder', [SeoSettingController::class, 'result_sortOrder']);



        //end seo task 

    });

    //submission prefix
    Route::group(['prefix' => 'seoSubmission'], function () {
        Route::post('/', [SeoSubmissionController::class, 'index']);
        Route::post('/store', [SeoSubmissionController::class, 'store']);
        Route::post('/update', [SeoSubmissionController::class, 'update']);
        Route::post('/edit', [SeoSubmissionController::class, 'edit']);
        Route::post('/destroy', [SeoSubmissionController::class, 'destroy']);
        Route::post('/create', [SeoSubmissionController::class, 'create']);
        Route::post('/getSubmissionUrl', [SeoSubmissionController::class, 'getSubmissionUrl']);
        Route::post('/ChangeSubmissionStatus', [SeoSubmissionController::class, 'ChangeSubmissionStatus']);
    });


    //seo daily work prefix


    Route::group(['prefix' => 'seoDailyWork'], function () {
        Route::post('/', [SeoWorkController::class, 'index']);
        Route::post('/edit', [SeoWorkController::class, 'edit']);
        Route::post('/dailyWorkStatus', [SeoWorkController::class, 'dailyWorkStatus']);
        Route::post('/work_report_update', [SeoWorkController::class, 'work_report_update']);
        Route::post('/postingupdate', [SeoWorkController::class, 'postingupdate']);
        Route::post('/work-posting-store', [SeoWorkController::class, 'postingstore']);
        Route::post('/duplicate_checker', [SeoWorkController::class, 'duplicate_checker']);
        Route::post('/landing_url_check', [SeoWorkController::class, 'landing_url_check']);
        Route::post('/duplicateCheckerUpdate', [SeoWorkController::class, 'duplicateCheckerUpdate']);
        Route::post('/taskSearch', [SeoWorkController::class, 'taskSearch']);

        
    });


    //seo work report
    Route::group(['prefix' => 'seoWorkReport'], function () {
        Route::post('/', [SeoReportController::class, 'index']);
        Route::post('/importAdd', [SeoReportController::class, 'importAdd']);
        Route::post('/importStore', [SeoReportController::class, 'importStore']);
        Route::post('/work_report', [SeoReportController::class, 'work_report']);

        Route::post('/exportData', [SeoReportController::class, 'exportData']);
    });



    //seo monthly result
    Route::group(['prefix' => 'seoMonthlyResult'], function () {
        Route::post('/', [SeoResultController::class, 'index']);
        Route::post('/store', [SeoResultController::class, 'store']);
        Route::post('/getMonthlyResult', [SeoResultController::class, 'getMonthlyResult']);

        Route::post('/export-monthly-result', [SeoResultController::class, 'exportMonthlyResult']);
    });

    // Seo Web Redirects  

    Route::group(['prefix' => 'seo-web-redirector'], function () {
        Route::post('/', [SeoWebRedirectorController::class, 'index']);
        Route::post('/store', [SeoWebRedirectorController::class, 'store']);
        Route::post('/edit', [SeoWebRedirectorController::class, 'edit']);
        Route::post('/update', [SeoWebRedirectorController::class, 'update']);
        Route::post('/change-status', [SeoWebRedirectorController::class, 'changeStatus']);
        Route::post('/delete', [SeoWebRedirectorController::class, 'destroy']);
    });
});
